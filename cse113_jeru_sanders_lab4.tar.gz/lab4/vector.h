#ifndef VECTOR_H_
#define VECTOR_H_

void multiply_array(int array[], int size, int multiplier);
void add_array(int array[], int size, int adder);
void add_arrays(int array1[], int array2[], int array3[], int size);
void multiply_arrays(int array1[], int array2[], int array3[], int size);
void inversemul_arrays(int array1[], int array2[], int array3[], int size);
void generate_array(int a[], int x);

#endif
