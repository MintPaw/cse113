var searchData=
[
  ['empty_5fmatrix',['empty_matrix',['../life_8c.html#af926e0a2d29d98c32c11785811e9a839',1,'life.c']]]
];
