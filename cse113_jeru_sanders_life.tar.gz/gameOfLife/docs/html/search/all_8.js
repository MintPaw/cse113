var searchData=
[
  ['sdl_5finfo_5ft',['sdl_info_t',['../structsdl__info__t.html',1,'']]],
  ['set_5fvalue',['set_value',['../life_8c.html#a6e520a46c4494fa98b8a1f26c10c6d51',1,'life.c']]],
  ['setup_5fmatrix',['setup_matrix',['../life_8c.html#a236e8cad1cb21994e249adad69422180',1,'life.c']]]
];
