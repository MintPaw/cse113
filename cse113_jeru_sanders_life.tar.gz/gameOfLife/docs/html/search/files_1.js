var searchData=
[
  ['life_2ec',['life.c',['../life_8c.html',1,'']]]
];
