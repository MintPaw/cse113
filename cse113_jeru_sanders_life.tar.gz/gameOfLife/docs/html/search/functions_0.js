var searchData=
[
  ['compute_5fmatrix',['compute_matrix',['../life_8c.html#aa6d09da7720ddcf7c5604540de988728',1,'life.c']]]
];
