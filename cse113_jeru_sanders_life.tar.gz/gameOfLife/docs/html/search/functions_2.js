var searchData=
[
  ['get_5fvalue',['get_value',['../life_8c.html#ab20978b9559911350798573b1cfd6b7d',1,'life.c']]]
];
