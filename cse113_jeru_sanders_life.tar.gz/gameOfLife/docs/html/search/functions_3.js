var searchData=
[
  ['normalize_5fpoints',['normalize_points',['../life_8c.html#a5318c35bad1464b2350adef453780530',1,'life.c']]]
];
