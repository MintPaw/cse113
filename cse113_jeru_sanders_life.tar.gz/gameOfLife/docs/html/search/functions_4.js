var searchData=
[
  ['parse_5ffile',['parse_file',['../life_8c.html#afe7ac5842f2ebbbd3b5cd676528bcddd',1,'life.c']]]
];
