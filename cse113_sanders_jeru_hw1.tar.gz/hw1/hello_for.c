#include <stdio.h>

int main(void)
{
	int i;
	for (i = 0; i < 20; i++)
	{
		printf("Hello world\n");
	}
	return 0;
}
