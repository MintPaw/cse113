#include <stdio.h>

int main(void)
{
	printf("JJJJJJJJJJJJJJJJJJJ                                                             \n");
	printf("        J               eeee       r  rrrr                                      \n");
	printf("        J              e    e      rrr    rrr   u       u                       \n");
	printf("        J             e      e     r            u       u                       \n");
	printf("        J             eeeeeeee     r            u       u                       \n");
	printf("        J             e            r            u       u                       \n");
	printf("J       J             e            r            u       u                       \n");
	printf("J       J              e           r            u       u                       \n");
	printf("JJJJJJJJJ               eeee       r             uuuuuuuu                       \n");
	printf("                                                        u                       \n");
	printf("                                                                                \n");
	printf("                                                                                \n");
	printf("                                                                                \n");
	printf("                                                                                \n");
	printf("                                                                                \n");
	printf("                                                                                \n");
	printf("                                                                                \n");
	printf("                                                                                \n");
	printf("                                                                                \n");
	printf("                                                                                \n");
	return 0;
}
